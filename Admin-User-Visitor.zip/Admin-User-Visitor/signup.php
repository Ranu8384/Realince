<?php
session_start();
require_once("connection.php");

if(!isset($_SESSION['contact'])){
    header("location:userlogin.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guest User Sign Up Form</title>

    <script>
        function checkGuest() {
            var contact = document.getElementById('contact').value;
            var password = document.getElementById('password').value;
            var cpass = document.getElementById('cpass').value;
            var phoneRegex = /^\d{10}$/;
           
            if(!contact || !password){
                alert("Please fill all the fields!");
                return false;
            } 
            if(!phoneRegex.test(contact)){
                alert("Enter valid contact number!");
                return false;
            } 
            if(password != cpass){
                alert("Password do not match!");
                return false;
            }
        }
    </script>
</head>
<body>
    <div id="main">
        <form action="database.php" method="post">
           Contact Number:- <input type="number" name="contact" id="contact"> <br><br>
           Password:- <input type="password" name="password" id="password"><br><br>
           Confirm Password:- <input type="password" name="cpass" id="cpass"><br><br>
           <button name="signup" id="signup" onclick="checkGuest()">Sign Up</button>
           <button type="reset">Cancle</button>
        </form>
    </div>
</body>
</html>
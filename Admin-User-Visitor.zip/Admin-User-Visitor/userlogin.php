<?php
session_start();
require_once("connection.php");

if(isset($_POST['login'])){
    $contact = $_POST["contact"];
    $password = $_POST["password"];

    $sql = "select * from guestuser where contact=$contact and password=$password";
    $result = mysqli_query($con,$sql);

    if($result){
        
        $num = mysqli_num_rows($result);
        if($num == 1){
            $_SESSION['loggedin'] = true;
            $_SESSION['contact'] = $contact;
            echo '<script type=text/javascript> alert("You have login succsessfully.")</script>';
            header("location:perfume.php");
            exit;
        }else{
            echo '<script type=text/javascript> alert("Invalid username or password!")</script>';
        }
    }else{
        echo '<script type=text/javascript> alert("Something went wrong in database")</script>'.mysqli_error($con);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guest User Login</title>
    <script>
        function checkLogin(){
            var contact = document.getElementById('contact').value;
            var password = document.getElementById('password').value;

            if(!contact || !password){
                alert("Field can't be empty!");
            }
        }
    </script>
</head>
<body>
    <div id="id">
        <form action="" method="post">
            Contact Number:- <input type="number" name="contact" id="contact"><br><br>
            Password:- <input type="password" name="password" id="password"><br><br>
           <button name="login" id="login" onclick="checkLogin()">Login</button>
           <button type="reset">Cancle</button>
        </form>
    </div>
</body>
</html>
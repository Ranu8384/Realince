<?php
require_once("connection.php");

if(isset($_POST['add'])){
    $name = $_POST["name"];
    $brand=$_POST["brand"];
    $price= $_POST["price"];
    $description=$_POST["description"];

    $sql = "INSERT INTO `shopping`.`perfumes` (`name`, `brand`, `price`, `description`) VALUES ('$name', '$brand', $price, '$description')";
    $result = mysqli_query($con, $sql);

    if($result){
        echo "<script> alert('Perfumes Added Successfully!') </script>";
        header("location:perfume.php");
    }else{
        echo"<script> alert('Error in sql!') </script>".mysqli_error($con);
    }
}

if(isset($_POST['signup'])){
    $contact = $_POST["contact"];
    $password = $_POST["password"];
    $cpass = $_POST["cpass"];

    if($password == $cpass){
    $sql = "insert into `shopping`.`guestuser` (`contact`,`password`) values ($contact,$password)";
    $result = mysqli_query($con,$sql);

    if($result){
        echo '<script type="text/javascript">alert("Guest User Registered successfully")</script>';
        header("location:userlogin.php");
    }else{
        echo'<script type="text/javascript">alert("Error in SQL!")</script>'.mysqli_error($con);
    }
}else{
    echo '<script type="text/javascript">alert("Password does not match!")</script>';
    header("location:signup.php");
}
}
?>
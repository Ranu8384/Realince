<?php
require_once("connection.php");

$sql = "select * from perfumes";
$result = mysqli_query($con,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Perfumes</title>
</head>
<body>
    <div id="main">
        <table border="1" cellspacing="0">
            <tr>
                <th>Perfume Id</th>
                <th>Perfume Name</th>
                <th>Perfume Brand</th>
                <th>Price</th>
                <th>Description</th>
            </tr>

            <?php
                while($row = mysqli_fetch_assoc($result)){
            ?>

            <tr>
                <td><?php echo $row['id'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['brand'] ?></td>
                <td><?php echo $row['price'] ?></td>
                <td><?php echo $row['description'] ?></td>
            </tr>

            <?php
                }
            ?>
        </table>
    </div>
</body>
</html>
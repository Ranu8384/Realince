<?php
session_start();
require_once("connection.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Site</title>
    <script>
        function checkPerfume() {
            var name = document.getElementById('name').value;
            var brand = document.getElementById('brand').value;
            var price = document.getElementById('price').value;
            var description = document.getElementById('description').value;

            if (!name || !brand || !price || !description) {
                alert("Field's can't be empty!");
                return false;
                window.location.href = "admin.php";
            }
        }
    </script>
</head>

<body>
    <a href="perfume.php">
        <button> Show All Perfumes</button>
    </a>

    <div id="main" style="margin-top: 25px;">
        <form action="database.php" method="post">
            Perfume Name:- <input type="text" name="name" id="name"><br><br>
            Perfume Brand:- <input type="text" name="brand" id="brand"><br><br>
            Price:- <input type="text" name="price" id="price"><br><br>
            Description:- <input type="text" name="description" id="description"><br><br>
            <button name="add" id="add" onclick="checkPerfume()">Add Perfume</button>
            <button type="reset">Cancle</button>
        </form>
    </div>
</body>

</html>
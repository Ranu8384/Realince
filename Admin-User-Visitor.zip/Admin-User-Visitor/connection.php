<?php
$con = mysqli_connect("localhost", "root", "adirp7", "shopping");
if(!$con){
    echo"Datbase is not connected!";
}
?>